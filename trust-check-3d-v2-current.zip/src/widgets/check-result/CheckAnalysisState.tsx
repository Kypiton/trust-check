"use client";

import Link from "next/link";
import type { CheckAnalysis } from "@/entities/check/model/types";
import { useLocale } from "@/shared/i18n/LocaleProvider";
import { AnalysisActivity } from "./AnalysisActivity";
import { CheckResult } from "./CheckResult";

const primaryAction = "inline-flex min-h-11 items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary-hover focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary";
const secondaryAction = "inline-flex min-h-11 items-center justify-center rounded-md border border-border bg-surface px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-surface-secondary focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary";
function InfoIcon({ className }: { className: string }) { return <svg aria-hidden="true" className={`size-5 shrink-0 ${className}`} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round"><circle cx="12" cy="12" r="9" /><path d="M12 11v5m0-9h.01" /></svg>; }

export function PartialAnalysisNotice() {
  const ru = useLocale() === "ru";
  return <aside aria-labelledby="partial-heading" className="flex items-start gap-3 rounded-xl border border-border bg-surface p-4 md:p-5"><InfoIcon className="mt-0.5 text-warning" /><div><h2 id="partial-heading" className="text-sm font-semibold">{ru ? "Некоторые проверки были недоступны" : "Some checks were unavailable"}</h2><p className="mt-1 text-sm leading-6 text-muted">{ru ? "Результат основан на информации, которую удалось проверить." : "The result is based on the information we could verify."}</p></div></aside>;
}

export function CheckAnalysisState({ analysis, onRetry, onNewCheck, fresh = false }: { analysis: CheckAnalysis; fresh?: boolean; onRetry?: () => void; onNewCheck?: () => void }) {
  const ru = useLocale() === "ru";
  if (analysis.status === "COMPLETED" || analysis.status === "PARTIAL") return <div className="space-y-6">{analysis.status === "PARTIAL" && <PartialAnalysisNotice />}<CheckResult fresh={fresh} result={analysis.result} /></div>;
  if (analysis.status === "ANALYZING") {
    const mode = analysis.steps[0]?.code;
    return <AnalysisActivity mode={mode === "SCREENSHOT" || mode === "URL" ? mode : "TEXT"} />;
  }
  const failed = analysis.status === "FAILED";
  const unsupportedLanguage = analysis.status === "INSUFFICIENT_DATA" && analysis.reason === "UNSUPPORTED_LANGUAGE";
  const noReadableText = analysis.status === "INSUFFICIENT_DATA" && analysis.reason === "NO_READABLE_TEXT";
  return <section aria-labelledby="outcome-heading" className="rounded-xl border border-border bg-surface p-5 md:p-8"><div className="flex items-center gap-3"><InfoIcon className={failed ? "text-danger" : "text-muted"} /><h1 id="outcome-heading" className="text-2xl font-semibold tracking-tight">{failed ? (ru ? "Не удалось выполнить анализ" : "Analysis failed") : unsupportedLanguage ? (ru ? "Нужен русский или английский текст" : "English or Russian text required") : (ru ? "Недостаточно информации" : "Not enough information")}</h1></div><p className="mt-3 text-base leading-7 text-muted">{failed ? (ru ? "Во время проверки произошла ошибка." : "Something went wrong while checking this content.") : unsupportedLanguage ? (ru ? "Анализ текста поддерживает русский и английский языки. Не удалось оценить это сообщение." : "Text analysis supports English and Russian. We could not assess this message.") : noReadableText ? (ru ? "Не удалось распознать читаемый текст на скриншоте. Загрузите более чёткое изображение." : "We couldn't find readable text in this screenshot. Please upload a clearer screenshot.") : (ru ? "Нужно больше информации, чтобы оценить содержимое." : "We need more information to assess this content.")}</p>{!failed && !unsupportedLanguage && <ul className="mt-5 list-disc space-y-2 pl-5 text-sm leading-6 text-muted"><li>{ru ? "Вставьте сообщение полностью" : "Paste the full message"}</li><li>{ru ? "Укажите полную ссылку" : "Provide a complete link"}</li><li>{ru ? "Загрузите более чёткий скриншот" : "Upload a clearer screenshot"}</li></ul>}<div className="mt-7 flex flex-col gap-3 sm:flex-row">{failed && <button type="button" onClick={onRetry} className={primaryAction}>{ru ? "Попробовать снова" : "Try again"}</button>}{onNewCheck ? <button type="button" onClick={onNewCheck} className={failed ? secondaryAction : primaryAction}>{ru ? "Новая проверка" : "Start a new check"}</button> : <Link href="/check" className={failed ? secondaryAction : primaryAction}>{ru ? "Новая проверка" : "Start a new check"}</Link>}</div></section>;
}
