export { TrustCoreHero } from "./TrustCoreHero";
