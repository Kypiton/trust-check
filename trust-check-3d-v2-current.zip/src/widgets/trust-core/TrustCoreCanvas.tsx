'use client';

import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { useMemo, useRef } from 'react';
import * as THREE from 'three';

type Palette = {
  foreground: string;
  muted: string;
  primary: string;
  danger: string;
  surface: string;
  border: string;
  dark: boolean;
};

export function TrustCoreCanvas({
  boosted,
  palette,
  active,
}: {
  boosted: boolean;
  palette: Palette;
  active: boolean;
}) {
  return (
    <div aria-hidden='true' className='absolute inset-0'>
      <Canvas
        dpr={[1, 1.5]}
        frameloop={active ? 'always' : 'demand'}
        camera={{ position: [0, 0.15, 7.4], fov: 40, near: 0.1, far: 50 }}
        gl={{ alpha: true, antialias: true, powerPreference: 'high-performance' }}
        style={{ position: 'absolute', inset: 0 }}
      >
        <TrustCoreScene boosted={boosted} palette={palette} />
      </Canvas>
    </div>
  );
}

function TrustCoreScene({ boosted, palette }: { boosted: boolean; palette: Palette }) {
  const root = useRef<THREE.Group>(null);
  const { pointer } = useThree();

  useFrame((state, delta) => {
    if (!root.current) return;
    const targetY = pointer.x * 0.14;
    const targetX = -pointer.y * 0.09;
    root.current.rotation.y = THREE.MathUtils.damp(root.current.rotation.y, targetY, 4.2, delta);
    root.current.rotation.x = THREE.MathUtils.damp(root.current.rotation.x, targetX, 4.2, delta);
    root.current.position.z = THREE.MathUtils.damp(
      root.current.position.z,
      boosted ? 0.12 : 0,
      3.2,
      delta,
    );
  });

  return (
    <>
      <ambientLight intensity={palette.dark ? 0.45 : 0.8} />
      <pointLight
        position={[3.5, 3, 4]}
        color={palette.primary}
        intensity={boosted ? 22 : 14}
        distance={12}
      />
      <pointLight
        position={[-4, -2, 3]}
        color={palette.danger}
        intensity={palette.dark ? 6 : 3}
        distance={10}
      />
      <group ref={root} scale={boosted ? 1.025 : 1}>
        <ParticleField palette={palette} boosted={boosted} />
        <OrbitRings palette={palette} boosted={boosted} />
        <ConnectionWeb palette={palette} />
        <Core palette={palette} boosted={boosted} />
        <ScanPlane palette={palette} boosted={boosted} />
        <Orbiter
          kind='message'
          index={0}
          radius={2.55}
          speed={0.34}
          tilt={0.35}
          palette={palette}
          boosted={boosted}
        />
        <Orbiter
          kind='link'
          index={1}
          radius={2.95}
          speed={-0.27}
          tilt={-0.5}
          palette={palette}
          boosted={boosted}
        />
        <Orbiter
          kind='screenshot'
          index={2}
          radius={2.35}
          speed={0.3}
          tilt={0.82}
          palette={palette}
          boosted={boosted}
        />
      </group>
    </>
  );
}

const coreVertex = /* glsl */ `
  varying vec3 vNormalW;
  varying vec3 vWorldPosition;
  uniform float uTime;
  uniform float uEnergy;

  void main() {
    vec3 displaced = position;
    float wave = sin(position.y * 8.0 + uTime * 1.7) * 0.018;
    wave += sin(position.x * 10.0 - uTime * 1.3) * 0.012;
    displaced += normal * wave * (0.65 + uEnergy * 0.35);

    vec4 worldPosition = modelMatrix * vec4(displaced, 1.0);
    vWorldPosition = worldPosition.xyz;
    vNormalW = normalize(mat3(modelMatrix) * normal);
    gl_Position = projectionMatrix * viewMatrix * worldPosition;
  }
`;

const coreFragment = /* glsl */ `
  varying vec3 vNormalW;
  varying vec3 vWorldPosition;
  uniform float uTime;
  uniform float uEnergy;
  uniform float uDanger;
  uniform vec3 uPrimary;
  uniform vec3 uDangerColor;
  uniform vec3 uInner;

  void main() {
    vec3 viewDir = normalize(cameraPosition - vWorldPosition);
    float fresnel = pow(1.0 - max(dot(normalize(vNormalW), viewDir), 0.0), 2.25);
    float bands = 0.5 + 0.5 * sin(vWorldPosition.y * 12.0 - uTime * 2.1 + sin(vWorldPosition.x * 5.0));
    float pulse = 0.72 + 0.28 * sin(uTime * 2.4);
    vec3 accent = mix(uPrimary, uDangerColor, uDanger);
    vec3 color = mix(uInner, accent, clamp(fresnel * 1.2 + bands * 0.18, 0.0, 1.0));
    color += accent * fresnel * (0.24 + 0.28 * uEnergy) * pulse;
    float alpha = 0.48 + fresnel * 0.42 + bands * 0.06;
    gl_FragColor = vec4(color, alpha);
  }
`;

function Core({ palette, boosted }: { palette: Palette; boosted: boolean }) {
  const shell = useRef<THREE.Mesh>(null);
  const wire = useRef<THREE.Mesh>(null);
  const material = useRef<THREE.ShaderMaterial>(null);
  const halo = useRef<THREE.Mesh>(null);

  const uniforms = useMemo(
    () => ({
      uTime: { value: 0 },
      uEnergy: { value: 0.65 },
      uDanger: { value: 0 },
      uPrimary: { value: new THREE.Color(palette.primary) },
      uDangerColor: { value: new THREE.Color(palette.danger) },
      uInner: { value: new THREE.Color(palette.dark ? '#08111f' : '#ffffff') },
    }),
    [palette.dark, palette.danger, palette.primary],
  );

  useFrame((state, delta) => {
    const elapsed = state.clock.elapsedTime;
    const cycle = elapsed % 10;
    const scan = cycle > 4.2 && cycle < 7.4 ? Math.sin(((cycle - 4.2) / 3.2) * Math.PI) : 0;
    const energy = Math.min(1, 0.55 + scan * 0.42 + (boosted ? 0.25 : 0));

    if (material.current) {
      material.current.uniforms.uTime.value = elapsed;
      material.current.uniforms.uEnergy.value = THREE.MathUtils.damp(
        material.current.uniforms.uEnergy.value,
        energy,
        4,
        delta,
      );
      material.current.uniforms.uDanger.value = THREE.MathUtils.damp(
        material.current.uniforms.uDanger.value,
        scan * 0.9,
        3,
        delta,
      );
      material.current.uniforms.uPrimary.value.set(palette.primary);
      material.current.uniforms.uDangerColor.value.set(palette.danger);
    }

    if (shell.current) {
      const scale = 1 + Math.sin(elapsed * 1.7) * 0.016 + scan * 0.055;
      shell.current.scale.setScalar(scale);
      shell.current.rotation.y += delta * (boosted ? 0.16 : 0.09);
      shell.current.rotation.x += delta * 0.025;
    }

    if (wire.current) {
      wire.current.rotation.y -= delta * 0.11;
      wire.current.rotation.z += delta * 0.07;
    }

    if (halo.current) {
      const haloScale = 1.34 + Math.sin(elapsed * 1.35) * 0.035 + scan * 0.08;
      halo.current.scale.setScalar(haloScale);
    }
  });

  return (
    <group>
      <mesh ref={halo}>
        <sphereGeometry args={[1.12, 48, 48]} />
        <meshBasicMaterial
          color={palette.primary}
          transparent
          opacity={palette.dark ? 0.055 : 0.035}
          blending={THREE.AdditiveBlending}
          depthWrite={false}
        />
      </mesh>
      <mesh ref={shell}>
        <icosahedronGeometry args={[0.95, 5]} />
        <shaderMaterial
          ref={material}
          vertexShader={coreVertex}
          fragmentShader={coreFragment}
          uniforms={uniforms}
          transparent
          depthWrite={false}
          blending={THREE.AdditiveBlending}
          side={THREE.DoubleSide}
        />
      </mesh>
      <mesh ref={wire} scale={1.045}>
        <icosahedronGeometry args={[0.96, 2]} />
        <meshBasicMaterial
          color={palette.primary}
          transparent
          opacity={palette.dark ? 0.19 : 0.12}
          wireframe
          depthWrite={false}
        />
      </mesh>
      <mesh scale={0.58}>
        <sphereGeometry args={[0.95, 36, 36]} />
        <meshStandardMaterial
          color={palette.primary}
          emissive={palette.primary}
          emissiveIntensity={palette.dark ? 1.4 : 0.7}
          roughness={0.12}
          metalness={0.2}
          transparent
          opacity={0.82}
        />
      </mesh>
    </group>
  );
}

function OrbitRings({ palette, boosted }: { palette: Palette; boosted: boolean }) {
  const group = useRef<THREE.Group>(null);

  useFrame((_, delta) => {
    if (!group.current) return;
    group.current.rotation.y += delta * (boosted ? 0.085 : 0.045);
    group.current.rotation.z += delta * 0.018;
  });

  return (
    <group ref={group}>
      <Ring radius={2.3} rotation={[1.18, 0.12, 0.1]} palette={palette} opacity={0.19} />
      <Ring radius={2.72} rotation={[0.72, -0.36, 1.1]} palette={palette} opacity={0.12} />
      <Ring radius={3.08} rotation={[1.55, 0.18, -0.58]} palette={palette} opacity={0.085} />
    </group>
  );
}

function Ring({
  radius,
  rotation,
  palette,
  opacity,
}: {
  radius: number;
  rotation: [number, number, number];
  palette: Palette;
  opacity: number;
}) {
  return (
    <mesh rotation={rotation}>
      <torusGeometry args={[radius, 0.008, 8, 180]} />
      <meshBasicMaterial
        color={palette.primary}
        transparent
        opacity={opacity}
        depthWrite={false}
        blending={THREE.AdditiveBlending}
      />
    </mesh>
  );
}

function seededRandom(seed: number) {
  let value = seed >>> 0;
  return () => {
    value = (value * 1664525 + 1013904223) >>> 0;
    return value / 4294967296;
  };
}

function ParticleField({ palette, boosted }: { palette: Palette; boosted: boolean }) {
  const points = useRef<THREE.Points>(null);
  const positions = useMemo(() => {
    const random = seededRandom(20261113);
    const count = 360;
    const array = new Float32Array(count * 3);
    for (let index = 0; index < count; index += 1) {
      const radius = 2.1 + random() * 2.2;
      const theta = random() * Math.PI * 2;
      const phi = Math.acos(2 * random() - 1);
      array[index * 3] = radius * Math.sin(phi) * Math.cos(theta);
      array[index * 3 + 1] = radius * Math.cos(phi) * 0.72;
      array[index * 3 + 2] = radius * Math.sin(phi) * Math.sin(theta) * 0.7;
    }
    return array;
  }, []);

  useFrame((_, delta) => {
    if (!points.current) return;
    points.current.rotation.y += delta * (boosted ? 0.055 : 0.026);
    points.current.rotation.x += delta * 0.006;
  });

  return (
    <points ref={points}>
      <bufferGeometry>
        <bufferAttribute attach='attributes-position' args={[positions, 3]} />
      </bufferGeometry>
      <pointsMaterial
        color={palette.primary}
        size={boosted ? 0.028 : 0.021}
        transparent
        opacity={palette.dark ? 0.5 : 0.32}
        sizeAttenuation
        depthWrite={false}
        blending={THREE.AdditiveBlending}
      />
    </points>
  );
}

function ConnectionWeb({ palette }: { palette: Palette }) {
  const positions = useMemo(() => {
    const vertices = [
      [-2.75, 0.3, -0.2],
      [0, 0, 0],
      [2.45, 1.15, -0.35],
      [0, 0, 0],
      [1.55, -2.0, 0.25],
      [0, 0, 0],
      [-1.9, -1.6, -0.55],
      [0, 0, 0],
      [0.4, 2.45, -0.35],
      [0, 0, 0],
    ];
    return new Float32Array(vertices.flat());
  }, []);

  return (
    <lineSegments>
      <bufferGeometry>
        <bufferAttribute attach='attributes-position' args={[positions, 3]} />
      </bufferGeometry>
      <lineBasicMaterial
        color={palette.primary}
        transparent
        opacity={palette.dark ? 0.085 : 0.055}
        depthWrite={false}
      />
    </lineSegments>
  );
}

function ScanPlane({ palette, boosted }: { palette: Palette; boosted: boolean }) {
  const scan = useRef<THREE.Mesh>(null);
  const material = useRef<THREE.MeshBasicMaterial>(null);

  useFrame(state => {
    const elapsed = state.clock.elapsedTime;
    const cycle = elapsed % (boosted ? 6.5 : 8.5);
    const start = boosted ? 1.6 : 3;
    const duration = boosted ? 2.6 : 2.9;
    const progress = THREE.MathUtils.clamp((cycle - start) / duration, 0, 1);
    const active = progress > 0 && progress < 1;
    if (scan.current) {
      scan.current.position.y = THREE.MathUtils.lerp(-1.35, 1.35, progress);
      scan.current.scale.setScalar(0.82 + Math.sin(progress * Math.PI) * 0.18);
    }
    if (material.current)
      material.current.opacity = active
        ? Math.sin(progress * Math.PI) * (palette.dark ? 0.42 : 0.3)
        : 0;
  });

  return (
    <mesh ref={scan} rotation={[Math.PI / 2, 0, 0]}>
      <ringGeometry args={[0.72, 1.28, 96]} />
      <meshBasicMaterial
        ref={material}
        color={palette.primary}
        transparent
        opacity={0}
        depthWrite={false}
        side={THREE.DoubleSide}
        blending={THREE.AdditiveBlending}
      />
    </mesh>
  );
}

type OrbiterKind = 'message' | 'link' | 'screenshot';

function Orbiter({
  kind,
  index,
  radius,
  speed,
  tilt,
  palette,
  boosted,
}: {
  kind: OrbiterKind;
  index: number;
  radius: number;
  speed: number;
  tilt: number;
  palette: Palette;
  boosted: boolean;
}) {
  const group = useRef<THREE.Group>(null);
  const lineAttribute = useRef<THREE.BufferAttribute>(null);
  const lineMaterial = useRef<THREE.LineBasicMaterial>(null);
  const { camera } = useThree();

  useFrame((state, delta) => {
    if (!group.current) return;
    const elapsed = state.clock.elapsedTime;
    const cycleDuration = boosted ? 7.5 : 10.5;
    const sceneCycle = elapsed % cycleDuration;
    const selected = Math.floor(elapsed / cycleDuration) % 3;
    const phaseStart = boosted ? 1.5 : 3.8;
    const phaseDuration = boosted ? 3.3 : 3.5;
    const localProgress = THREE.MathUtils.clamp((sceneCycle - phaseStart) / phaseDuration, 0, 1);
    const pull = selected === index ? Math.sin(localProgress * Math.PI) : 0;
    const currentRadius = THREE.MathUtils.lerp(radius, 1.35, pull * 0.88);
    const theta = elapsed * speed + index * 2.1;

    const x = Math.cos(theta) * currentRadius;
    const z = Math.sin(theta) * currentRadius * 0.56;
    const y = Math.sin(theta * 1.17 + tilt) * (0.58 + Math.abs(tilt) * 0.32);
    group.current.position.set(x, y, z);
    group.current.lookAt(camera.position);
    const targetScale = 0.92 + pull * 0.28 + (boosted ? 0.035 : 0);
    const scale = THREE.MathUtils.damp(group.current.scale.x, targetScale, 5, delta);
    group.current.scale.setScalar(scale);

    if (lineAttribute.current) {
      lineAttribute.current.setXYZ(0, 0, 0, 0);
      lineAttribute.current.setXYZ(1, x, y, z);
      lineAttribute.current.needsUpdate = true;
    }
    if (lineMaterial.current)
      lineMaterial.current.opacity = 0.05 + pull * (palette.dark ? 0.33 : 0.2);
  });

  return (
    <>
      <line>
        <bufferGeometry>
          <bufferAttribute
            ref={lineAttribute}
            attach='attributes-position'
            args={[new Float32Array(6), 3]}
          />
        </bufferGeometry>
        <lineBasicMaterial
          ref={lineMaterial}
          color={palette.primary}
          transparent
          opacity={0.05}
          depthWrite={false}
        />
      </line>
      <group ref={group}>
        {kind === 'message' && <MessageNode palette={palette} />}
        {kind === 'link' && <LinkNode palette={palette} />}
        {kind === 'screenshot' && <ScreenshotNode palette={palette} />}
      </group>
    </>
  );
}

function NodeMaterial({ palette, opacity = 0.92 }: { palette: Palette; opacity?: number }) {
  return (
    <meshStandardMaterial
      color={palette.surface}
      emissive={palette.primary}
      emissiveIntensity={palette.dark ? 0.16 : 0.045}
      roughness={0.36}
      metalness={0.12}
      transparent
      opacity={opacity}
    />
  );
}

function MessageNode({ palette }: { palette: Palette }) {
  return (
    <group>
      <mesh>
        <boxGeometry args={[1.16, 0.76, 0.09]} />
        <NodeMaterial palette={palette} />
      </mesh>
      {[0.18, 0, -0.18].map((y, index) => (
        <mesh key={y} position={[-0.1 + index * 0.03, y, 0.055]}>
          <boxGeometry args={[0.68 - index * 0.12, 0.045, 0.018]} />
          <meshBasicMaterial
            color={index === 0 ? palette.primary : palette.muted}
            transparent
            opacity={index === 0 ? 0.88 : 0.5}
          />
        </mesh>
      ))}
      <mesh position={[-0.43, 0.19, 0.06]}>
        <sphereGeometry args={[0.07, 18, 18]} />
        <meshBasicMaterial color={palette.primary} />
      </mesh>
    </group>
  );
}

function LinkNode({ palette }: { palette: Palette }) {
  return (
    <group>
      <mesh rotation={[0, 0, -0.55]} position={[-0.24, 0, 0]}>
        <torusGeometry args={[0.28, 0.085, 16, 36, Math.PI * 1.42]} />
        <meshStandardMaterial
          color={palette.primary}
          emissive={palette.primary}
          emissiveIntensity={palette.dark ? 0.35 : 0.08}
          roughness={0.25}
          metalness={0.22}
        />
      </mesh>
      <mesh rotation={[0, 0, -0.55]} position={[0.24, 0, 0]}>
        <torusGeometry args={[0.28, 0.085, 16, 36, Math.PI * 1.42]} />
        <meshStandardMaterial
          color={palette.surface}
          emissive={palette.primary}
          emissiveIntensity={palette.dark ? 0.22 : 0.05}
          roughness={0.3}
          metalness={0.22}
        />
      </mesh>
      <mesh rotation={[0, 0, 0.2]}>
        <boxGeometry args={[0.46, 0.09, 0.1]} />
        <meshBasicMaterial color={palette.primary} />
      </mesh>
    </group>
  );
}

function ScreenshotNode({ palette }: { palette: Palette }) {
  return (
    <group>
      <mesh>
        <boxGeometry args={[0.94, 0.74, 0.08]} />
        <NodeMaterial palette={palette} />
      </mesh>
      <mesh position={[0, 0.03, 0.05]}>
        <planeGeometry args={[0.68, 0.42]} />
        <meshBasicMaterial
          color={palette.dark ? '#0b1220' : '#eaf2ff'}
          transparent
          opacity={0.94}
        />
      </mesh>
      <mesh position={[-0.21, 0.12, 0.06]}>
        <sphereGeometry args={[0.07, 16, 16]} />
        <meshBasicMaterial color={palette.primary} />
      </mesh>
      <mesh position={[0.11, -0.08, 0.061]} rotation={[0, 0, -0.48]}>
        <planeGeometry args={[0.5, 0.055]} />
        <meshBasicMaterial color={palette.muted} transparent opacity={0.7} />
      </mesh>
    </group>
  );
}
