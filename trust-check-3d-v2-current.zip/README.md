# TrustCheck

TrustCheck assesses scam and phishing risk in **Text**, **Link**, and **Screenshot**
inputs. Results explain risk, confidence, warning signs, recommended actions, and
analysis coverage. Low Risk is not a guarantee of safety.

- Text checks look for warning signs in English and Russian messages.
- Link checks combine URL structure, domain metadata, redirects, and threat reputation.
- Screenshot checks extract English or Russian text and links on the server using local OCR,
  then assess the extracted content. No external OCR service is used.
- Email/password accounts offer private History, saved result details, and deletion.
- Public checking, responsive navigation, English/Russian UI, and light/dark themes are available.
- Check UX includes safe examples, smart Link-mode suggestions for pasted URLs, screenshot drag/drop or clipboard paste, and copyable result summaries.

Anonymous analyses are not saved. Signed-in completed/partial results are saved
as metadata automatically. Raw messages, original links, images, extracted text,
and provider responses are excluded from saved History. External security providers
may receive submitted/detected links during link checks; analysis is not fully local.

### Trust Core 3D hero

The landing page includes a decorative procedural Trust Core scene built with React Three Fiber + Three.js. It is isolated from the analysis pipeline, lazy-loaded near the hero, uses a lightweight mobile/WebGL fallback, and disables continuous motion when `prefers-reduced-motion` is enabled. The scene is explicitly labeled as an illustration and never represents a real assessment.


## Getting Started

### Local PostgreSQL

The development database uses PostgreSQL 17 Alpine in Docker with a named volume
so data survives container restarts. The credentials below are for local use only.

Set this value in the Git-ignored `.env.local`, preserving any existing settings:

```dotenv
DATABASE_URL="postgresql://trustcheck:trustcheck_dev@localhost:5433/trustcheck"
```

Start Docker, then run:

```bash
docker compose up -d --wait --wait-timeout 60
npx prisma migrate deploy
npx prisma validate
npx prisma generate
```

Host port 5433 must be available. `docker compose ps` shows database health.
`docker compose stop` stops PostgreSQL without deleting its data. The named
volume stays outside the repository; do not remove it if you want to keep data.
The `Check` schema stores result metadata only. Authenticated analyses save their
completed or partial assessments; anonymous analyses are never saved.

### Local authentication

Better Auth provides email/password registration at `/register` and sign-in at
`/login`. Set `BETTER_AUTH_URL="http://localhost:3000"` and a cryptographically
random `BETTER_AUTH_SECRET` of at least 32 bytes in the ignored `.env.local`.
Keep the secret stable between restarts and never commit it. `.env.example`
contains only empty placeholders. Apply the existing migrations with the command
above before using authentication.

Passwords must contain at least 10 characters. Better Auth handles password
hashing and database-backed sessions. `/history` requires a validated session;
`/check` remains public. Sign-up, sign-in, and sign-out return to `/check`.
Email verification and password reset are not enabled yet. History displays only
the authenticated user's latest 50 checks, newest first, with dates in UTC.
The list selects lightweight assessment metadata and does not load result JSON
payloads. History rows open authenticated saved results at `/check/[id]`. Each detail query
filters by both Check ID and session user ID. Stored JSON is validated before
rendering; historical scores and confidence are never recalculated. Missing or
other-user checks share the same 404 behavior. Known sample IDs work only in
development. Pagination is not implemented yet.

Saved checks can be permanently deleted individually from History or a saved
result, or cleared together from History and `/account/privacy`. Each action
requires confirmation and a validated session, and the database deletion is
scoped to that user. Missing and other-user IDs return the same unavailable
outcome. Deletion removes saved results from the application database while
keeping accounts and sign-in sessions.

### Analysis persistence

Text, Link, and Screenshot Server Actions save final `COMPLETED` and `PARTIAL`
assessments once, using the server-validated session for ownership. The server-only
Check persistence layer explicitly maps display metadata into Prisma JSON fields;
the optional analysis note is stored as an array in `analysisNotes`. Submitted
content, images, filenames, OCR text, raw URLs, and provider responses are excluded.
Validation errors, failed analyses, and insufficient-data results are not saved.

A successful write adds only `persistedCheckId` to the action response. Session
lookup or storage failures leave the valid analysis intact without an ID. The UI
does not redirect or change its presentation when a Check is saved.


### Rate limiting

Authentication uses Better Auth's official database-backed limiter. It is enabled
in all environments: the default limit is 100 requests/minute (300 in development),
sign-in is 10/minute (30 in development), and sign-up is 5/minute (20 in development).
The official `RateLimit` schema is generated by Better Auth. A Prisma query
extension HMACs only its IP/path keys before storage; Better Auth still owns all
counter and endpoint policy logic.

Analysis uses separate atomic PostgreSQL fixed-window buckets:

| Actor | Text | Link | Screenshot |
| --- | ---: | ---: | ---: |
| Anonymous | 10 | 5 | 3 |
| Signed in | 30 | 15 | 8 |

Each quota applies to a separate 10-minute window starting with the first request.
A conditional parameterized UPSERT admits and increments under the database row
lock, including concurrent window resets. Denied requests do not run analysis or
save Checks. Storage/session/identity failures fail closed in every environment,
with a generic temporary-unavailable response. The form keeps its input for retry.

Set a strong, stable `RATE_LIMIT_SECRET` (at least 32 random bytes) in the ignored
`.env.local` or deployment secret store. Anonymous keys use HMAC-SHA256 of the
canonical client IP; authenticated analysis keys contain only the internal user ID
and operation. Neither rate-limit table contains raw IPs, emails or input content.
Use the same secret across instances. Rotating it starts new anonymous/auth buckets.

Local development ignores supplied IP headers and shares a loopback anonymous
bucket. In production, anonymous analysis fails closed until proxy trust is
explicitly configured. Set `TRUST_PROXY_IP_HEADERS=true` and
`TRUSTED_CLIENT_IP_HEADER` to one header that your trusted proxy **overwrites**
with a single client IP (for example `x-real-ip`). The origin must be reachable
only through that proxy. Multi-address forwarding chains and malformed addresses
are rejected; no arbitrary `X-Forwarded-For` is trusted. Better Auth uses the same
header configuration; without it, production auth shares its conservative
per-path fallback bucket. Do not disable IP tracking to configure rate limiting.

`cleanupRateLimitBuckets()` in `src/shared/server/rate-limit/cleanup.ts` removes
analysis/auth buckets older than 24 hours. It is an explicit server maintenance
entry point, not invoked per request or scheduled automatically.

To reset **local development quotas only**, without deleting users or saved checks:

```bash
docker compose exec postgres psql -U trustcheck -d trustcheck -c 'TRUNCATE TABLE "AnalysisRateLimit", "rateLimit";'
```

### Run and validate

Install dependencies with `npm ci`, configure the ignored `.env.local`, and apply
migrations as above. Run `npm run dev` and open http://localhost:3000.

| Environment variable | Purpose |
| --- | --- |
| `DATABASE_URL` | Server-only PostgreSQL connection (local URL above). |
| `APP_URL` | Canonical application origin. Local fallback is `http://localhost:3000`; production requires the real public HTTPS origin. |
| `BETTER_AUTH_URL` | Application origin, locally `http://localhost:3000`. |
| `BETTER_AUTH_SECRET` | Strong, stable authentication secret. |
| `RATE_LIMIT_SECRET` | Strong, stable rate-limit key secret. |
| `GOOGLE_WEB_RISK_API_KEY` | Optional threat reputation provider key. Missing configuration is reflected in coverage. |
| `TRUST_PROXY_IP_HEADERS`, `TRUSTED_CLIENT_IP_HEADER` | Production proxy trust; see the rate-limit section. |

Never commit `.env.local` or expose server secrets through `NEXT_PUBLIC_` variables.

```bash
npx prisma validate
npm test
npm run lint
npx tsc --noEmit
npm run build
```

If the environment cannot run Turbopack workers, `npm run build -- --webpack`
is the supported build fallback. Development-only result previews live at
`/check/high`, `/check/medium`, `/check/low`, `/check/partial`, `/check/loading`,
`/check/error`, and `/check/insufficient`; these do not expose sample results in production.

### UI motion and feedback

Motion (`motion/react`) provides the shared input selector, restrained button
feedback, one-time section reveals, and transient notifications. Fresh results
count up visually for 600 ms; assistive technology receives the final score
immediately, and saved results remain static. Reduced-motion preferences disable
movement. Waiting screens describe possible checks, never fabricated progress.

Tailwind runs through its official PostCSS plugin for both webpack and Turbopack.
This is required for `npm run build -- --webpack` to include utility styles.

## Production deployment

Use a Node.js host (Node 22.22.2+ or another supported release satisfying the installed package engines), PostgreSQL, HTTPS, and a
trusted reverse proxy. This app needs Node workers/native dependencies for Sharp
and Tesseract; an edge-only/static deployment is unsuitable. Install with `npm ci`;
keep the traced OCR worker, English/Russian language data, and native dependencies
in the deployment artifact. Do not deploy the local Docker Compose credentials.

Configure the variables documented in `.env.example` in the hosting secret store:
`DATABASE_URL`, `APP_URL`, `BETTER_AUTH_URL`, `BETTER_AUTH_SECRET`,
`RATE_LIMIT_SECRET`, `TRUST_PROXY_IP_HEADERS`, and `TRUSTED_CLIENT_IP_HEADER`.
`APP_URL` is the canonical public HTTPS origin, without a path/query/fragment. Reserved documentation/test domains are rejected so a placeholder cannot become the production canonical;
`BETTER_AUTH_URL` must match it. Set these **before building and at runtime**;
rebuild when the canonical origin changes. No production localhost fallback exists.
Startup rejects missing/malformed critical settings with value-free error messages.
`GOOGLE_WEB_RISK_API_KEY` remains optional; missing credentials skip that provider.
Generate the two secrets independently using a cryptographic random generator
and keep them stable across replicas/restarts. Never use example values in production.

The proxy must overwrite the selected header with one verified client IP, strip
client-supplied copies, and prevent direct access to the app origin. Merely setting
the two trust variables does not establish trust. Confirm this with the chosen
host before public launch. See the rate-limit section for quotas and cleanup.

Deployment order:

1. Provision PostgreSQL; configure access, TLS as required by the database host,
   and a tested backup/restore process.
2. Configure production environment and the trusted HTTPS proxy.
3. Gate the release with the checks below; run `npx prisma migrate deploy` once
   against the intended database, then `npx prisma migrate status`. Do not use
   `migrate dev` or `db push` in production. Coordinate migrations/rollback before
   switching traffic; this release introduces no schema migration.
4. Deploy the generated client and production build, then `npm run start` (or the
   host's equivalent). Do not use `next dev` publicly.
5. Complete [the release checklist](docs/release-checklist.md) on the real origin:
   auth, EN/RU Text/OCR, Link, History/delete, rate limiting, and public metadata.

```bash
npm test
npm run lint -- --max-warnings 0
npx prisma validate
npx prisma generate
npm run build -- --webpack
npx tsc --noEmit
```

Run standalone TypeScript checks after the build, not concurrently with it:
Next regenerates `.next/types` during builds. Build/generate/validate do not apply
migrations. The installed Next version supports webpack as the production path.

### Indexing, headers and operational privacy

Only `/` and `/check` have canonical URLs and appear in the sitemap. History,
login/register, saved results, account/privacy and APIs are noindex. The privacy
page contains personal deletion controls and remains authenticated. Robots disallows
private paths; authorization still enforces ownership. Development robots disallows
all crawling and its sitemap is empty. Preview IDs render fixtures only in development.
Use host-level access protection for staging; robots is not access control.

`/opengraph-image` generates a static 1200×630 branded social preview using Next's
ImageResponse. Icons use the same shield mark; rebuild the raster versions with
`node scripts/generate-icons.mjs` after changing `src/app/icon.svg`.

Responses disable MIME sniffing, referrers and framing, and restrict camera,
microphone, geolocation and browser Topics access. Clipboard access remains available. Private routes/API
responses receive noindex and private/no-store headers. Do not configure a CDN to
cache session-dependent HTML or RSC responses; the shared header also reads the
session on public pages. The existing request-scoped React cache is not a shared
user-data cache.

CSP currently restricts framing only. A full script/style nonce policy is deferred
until it can be tested with the selected host, Next hydration and Motion. Configure
HSTS at the HTTPS edge after confirming certificates, redirects and subdomain policy;
no HSTS/preload directive is emitted for local development.

Application analysis/auth logs use generic event codes; OCR worker stdout/stderr are
discarded and raw exceptions are not returned to users. Configure hosting, proxy,
database and error-reporting logs to avoid request bodies, query strings, cookies,
authorization headers and provider payloads. Next development action argument logging is disabled; still use dummy content locally. No tracking SDK is included.
